package app.klima.tile

import android.app.AlertDialog
import android.content.ComponentName
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import org.json.JSONObject

private val ALL_TILES: List<Class<out TileService>> = listOf(
    PowerTile::class.java,
    TempUpTile::class.java,
    TempDownTile::class.java,
    ModeTile::class.java,
    FanTile::class.java,
    StatusTile::class.java,
)

abstract class BaseTile : TileService() {
    private val main = Handler(Looper.getMainLooper())

    protected abstract fun render(t: Tile, s: AcState?, err: String?)
    protected abstract fun patch(s: AcState): JSONObject?
    protected open fun iconRes(s: AcState?): Int = R.drawable.ic_ac

    override fun onStartListening() {
        paint(Ac.last, null)
        work(false)
    }

    override fun onClick() {
        work(true)
    }

    private fun work(click: Boolean) {
        val ctx = applicationContext
        Ac.exec.execute {
            var st: AcState? = null
            var err: String? = null
            try {
                st = if (click) Ac.apply(ctx) { patch(it) } else Ac.refresh(ctx, 3000)
                Store.setError(ctx, null)
            } catch (e: Exception) {
                err = e.message ?: "Hata"
                Store.setError(ctx, err)
            }
            main.post {
                paint(st ?: Ac.last, err)
                if (click) pokeOthers()
            }
        }
    }

    private fun paint(s: AcState?, err: String?) {
        val t = qsTile ?: return
        t.icon = Icon.createWithResource(this, iconRes(s))
        render(t, s, err)
        t.updateTile()
    }

    private fun pokeOthers() {
        for (c in ALL_TILES) {
            try {
                TileService.requestListeningState(this, ComponentName(this, c))
            } catch (_: Exception) {
            }
        }
    }

    protected fun tempSub(s: AcState): String = "Hedef ${s.target}° · Oda ${s.current ?: "?"}°"

    /** Hata, bekleme ve normal durum için ortak boyama. */
    protected fun fill(t: Tile, label: String, s: AcState?, err: String?, sub: (AcState) -> String) {
        t.label = label
        when {
            err != null -> {
                t.state = Tile.STATE_INACTIVE
                t.subtitle = "Hata"
            }
            s == null -> {
                t.state = Tile.STATE_INACTIVE
                t.subtitle = "…"
            }
            else -> {
                t.state = if (s.power == 1) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                t.subtitle = sub(s)
            }
        }
    }
}

class PowerTile : BaseTile() {
    override fun iconRes(s: AcState?): Int = R.drawable.ic_power

    override fun render(t: Tile, s: AcState?, err: String?) =
        fill(t, "Klima aç/kapat", s, err) { if (it.power == 1) "Açık" else "Kapalı" }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("powerSwitch", if (s.power == 1) 0 else 1)
}

class TempUpTile : BaseTile() {
    override fun iconRes(s: AcState?): Int = R.drawable.ic_up

    override fun render(t: Tile, s: AcState?, err: String?) =
        fill(t, "Sıcaklık artır", s, err) { tempSub(it) }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("targetTemperature", minOf(Ac.TEMP_MAX, s.target + 1))
}

class TempDownTile : BaseTile() {
    override fun iconRes(s: AcState?): Int = R.drawable.ic_down

    override fun render(t: Tile, s: AcState?, err: String?) =
        fill(t, "Sıcaklık azalt", s, err) { tempSub(it) }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("targetTemperature", maxOf(Ac.TEMP_MIN, s.target - 1))
}

class ModeTile : BaseTile() {
    // Isıtma güneş, diğer modlar kar tanesi
    override fun iconRes(s: AcState?): Int = if (s?.mode == 4) R.drawable.ic_sun else R.drawable.ic_ac

    override fun render(t: Tile, s: AcState?, err: String?) =
        fill(t, "Klima modu", s, err) { Ac.modeName(it.mode) }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("workMode", Ac.next(Ac.MODE_CYCLE, s.mode))
}

class FanTile : BaseTile() {
    override fun iconRes(s: AcState?): Int = R.drawable.ic_fan

    override fun render(t: Tile, s: AcState?, err: String?) =
        fill(t, "Fan hızı", s, err) { Ac.fanName(it.fan) }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("windSpeed", Ac.next(Ac.FAN_CYCLE, s.fan))
}

/** Basınca tüm durumu bir pencerede gösterir. */
class StatusTile : BaseTile() {
    private val ui = Handler(Looper.getMainLooper())

    override fun iconRes(s: AcState?): Int = R.drawable.ic_info

    override fun render(t: Tile, s: AcState?, err: String?) =
        fill(t, "Klima durumu", s, err) { "${if (it.power == 1) "Açık" else "Kapalı"} · ${it.target}°" }

    override fun patch(s: AcState): JSONObject? = null

    override fun onClick() {
        val ctx = applicationContext
        Ac.exec.execute {
            val text = try {
                Ac.describe(Ac.refresh(ctx, 3000))
            } catch (e: Exception) {
                "Hata: ${e.message}"
            }
            ui.post {
                val d = AlertDialog.Builder(this)
                    .setTitle("Klima")
                    .setMessage(text)
                    .setPositiveButton("Tamam", null)
                    .create()
                showDialog(d)
            }
        }
    }
}
