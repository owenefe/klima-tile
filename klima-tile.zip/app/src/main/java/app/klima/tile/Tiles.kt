package app.klima.tile

import android.content.ComponentName
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import org.json.JSONObject

private val ALL_TILES: List<Class<out TileService>> = listOf(
    PowerTile::class.java,
    TempUpTile::class.java,
    TempDownTile::class.java,
    ModeTile::class.java,
    FanTile::class.java,
)

abstract class BaseTile : TileService() {
    private val main = Handler(Looper.getMainLooper())

    protected abstract fun render(t: Tile, s: AcState?, err: String?)
    protected abstract fun patch(s: AcState): JSONObject?

    override fun onStartListening() {
        paint(Ac.last, null)
        work(false)
    }

    override fun onClick() {
        work(true)
    }

    private fun work(click: Boolean) {
        val ctx = applicationContext
        Ac.exec.execute {
            var st: AcState? = null
            var err: String? = null
            try {
                st = if (click) Ac.apply(ctx) { patch(it) } else Ac.refresh(ctx, 3000)
                Store.setError(ctx, null)
            } catch (e: Exception) {
                err = e.message ?: "Hata"
                Store.setError(ctx, err)
            }
            main.post {
                paint(st ?: Ac.last, err)
                if (click) pokeOthers()
            }
        }
    }

    private fun paint(s: AcState?, err: String?) {
        val t = qsTile ?: return
        t.icon = Icon.createWithResource(this, R.drawable.ic_ac)
        render(t, s, err)
        t.updateTile()
    }

    private fun pokeOthers() {
        for (c in ALL_TILES) {
            try {
                TileService.requestListeningState(this, ComponentName(this, c))
            } catch (_: Exception) {
            }
        }
    }

    protected fun tempSub(s: AcState): String = "Hedef ${s.target}° · Oda ${s.current ?: "?"}°"
}

class PowerTile : BaseTile() {
    override fun render(t: Tile, s: AcState?, err: String?) {
        t.label = "Klima"
        when {
            err != null -> {
                t.state = Tile.STATE_INACTIVE
                t.subtitle = "Hata (uygulamayı aç)"
            }
            s == null -> {
                t.state = Tile.STATE_INACTIVE
                t.subtitle = "…"
            }
            else -> {
                t.state = if (s.power == 1) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                t.subtitle = if (s.power == 1) "Açık" else "Kapalı"
            }
        }
    }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("powerSwitch", if (s.power == 1) 0 else 1)
}

class TempUpTile : BaseTile() {
    override fun render(t: Tile, s: AcState?, err: String?) {
        t.label = "Sıcaklık +"
        if (s == null || err != null) {
            t.state = Tile.STATE_INACTIVE
            t.subtitle = if (err != null) "Hata" else "…"
        } else {
            t.state = if (s.power == 1) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            t.subtitle = tempSub(s)
        }
    }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("targetTemperature", minOf(Ac.TEMP_MAX, s.target + 1))
}

class TempDownTile : BaseTile() {
    override fun render(t: Tile, s: AcState?, err: String?) {
        t.label = "Sıcaklık −"
        if (s == null || err != null) {
            t.state = Tile.STATE_INACTIVE
            t.subtitle = if (err != null) "Hata" else "…"
        } else {
            t.state = if (s.power == 1) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            t.subtitle = tempSub(s)
        }
    }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("targetTemperature", maxOf(Ac.TEMP_MIN, s.target - 1))
}

class ModeTile : BaseTile() {
    override fun render(t: Tile, s: AcState?, err: String?) {
        t.label = "Mod"
        if (s == null || err != null) {
            t.state = Tile.STATE_INACTIVE
            t.subtitle = if (err != null) "Hata" else "…"
        } else {
            t.state = if (s.power == 1) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            t.subtitle = Ac.modeName(s.mode)
        }
    }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("workMode", Ac.next(Ac.MODE_CYCLE, s.mode))
}

class FanTile : BaseTile() {
    override fun render(t: Tile, s: AcState?, err: String?) {
        t.label = "Fan"
        if (s == null || err != null) {
            t.state = Tile.STATE_INACTIVE
            t.subtitle = if (err != null) "Hata" else "…"
        } else {
            t.state = if (s.power == 1) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            t.subtitle = Ac.fanName(s.fan)
        }
    }

    override fun patch(s: AcState): JSONObject? =
        JSONObject().put("windSpeed", Ac.next(Ac.FAN_CYCLE, s.fan))
}
