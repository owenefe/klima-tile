package app.klima.tile

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class TclException(message: String, val auth: Boolean = false) : Exception(message)

data class Creds(
    val accessKey: String,
    val secretKey: String,
    val sessionToken: String,
    val expiresAtMs: Long,
)

data class Session(
    val username: String,
    val country: String,
    val deviceUrl: String,
    val region: String,
    val saasToken: String,
    val creds: Creds,
) {
    fun fresh(): Boolean = System.currentTimeMillis() < creds.expiresAtMs - 120_000
}

data class Device(val id: String, val name: String)

data class AcState(
    val power: Int,
    val target: Int,
    val current: Int?,
    val mode: Int?,
    val fan: Int?,
    val raw: String,
)

object Store {
    fun p(ctx: Context) = ctx.getSharedPreferences("klima", Context.MODE_PRIVATE)

    fun setError(ctx: Context, msg: String?) {
        val e = p(ctx).edit()
        if (msg == null) e.remove("error") else e.putString("error", msg)
        e.apply()
    }

    fun error(ctx: Context): String? = p(ctx).getString("error", null)
}

/**
 * TCL Home bulut istemcisi (resmi olmayan).
 * Protokol, açık kaynak "homebridge-tcl-home" eklentisinden uyarlanmıştır.
 */
object Tcl {
    private const val LOGIN_URL = "https://pa.account.tcl.com/account/login?clientId=54148614"
    private const val CLOUD_URL_GET = "https://prod-center.aws.tcljd.com/v3/global/cloud_url_get"
    private const val APP_ID = "wx6e1af3fa84fbe523"
    private const val JSON_TYPE = "application/json; charset=UTF-8"

    @Volatile
    private var cached: Session? = null

    // ---------- yardımcılar ----------

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    fun md5(s: String): String = hex(MessageDigest.getInstance("MD5").digest(s.toByteArray(Charsets.UTF_8)))

    private fun sha256Hex(s: String): String =
        hex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)))

    private fun hmac(key: ByteArray, data: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8))
    }

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 20000
        for ((k, v) in headers) c.setRequestProperty(k, v)
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        c.disconnect()
        return Pair(code, text)
    }

    private fun parse(text: String, step: String, code: Int): JSONObject {
        try {
            return JSONObject(text)
        } catch (e: Exception) {
            throw TclException("$step: beklenmeyen yanıt (HTTP $code): ${text.take(120)}")
        }
    }

    private fun jwtSub(token: String): String {
        val parts = token.split(".")
        if (parts.size < 2) throw TclException("cognitoToken biçimi beklenmedik")
        val json = String(
            Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP),
            Charsets.UTF_8,
        )
        return JSONObject(json).getString("sub")
    }

    private fun nonce(): String {
        val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        return (1..16).map { chars.random() }.joinToString("")
    }

    // ---------- giriş ----------

    private fun connect(user: String, pwMd5: String): Session {
        // 1) hesap girişi
        val loginBody = JSONObject()
            .put("equipment", 2)
            .put("password", pwMd5)
            .put("osType", 1)
            .put("username", user)
            .put("clientVersion", "4.8.1")
            .put("osVersion", "6.0")
            .put("deviceModel", "AndroidAndroid SDK built for x86")
            .put("captchaRule", 2)
            .put("channel", "app")
            .toString()
        val (c1, t1) = http(
            "POST", LOGIN_URL,
            mapOf(
                "th_platform" to "android",
                "th_version" to "4.8.1",
                "th_appbulid" to "830",
                "user-agent" to "Android",
                "content-type" to JSON_TYPE,
            ),
            loginBody,
        )
        val j1 = parse(t1, "giriş", c1)
        if (j1.optInt("status") != 1) {
            throw TclException("TCL girişi reddedildi (e-posta/şifre doğru mu?): ${t1.take(160)}", true)
        }
        val token = j1.getString("token")
        val u = j1.getJSONObject("user")
        val username = u.getString("username")
        val country = u.optString("countryAbbr", "")

        // 2) bulut adresleri
        val (c2, t2) = http(
            "POST", CLOUD_URL_GET,
            mapOf("content-type" to JSON_TYPE),
            JSONObject().put("ssoId", username).put("ssoToken", token).toString(),
        )
        val d2 = parse(t2, "bulut adresi", c2).optJSONObject("data")
            ?: throw TclException("bulut adresi alınamadı: ${t2.take(160)}")
        val cloudUrl = d2.getString("cloud_url").trimEnd('/')
        val deviceUrl = d2.getString("device_url").trimEnd('/')
        val region = d2.getString("cloud_region")

        // 3) jetonlar
        val (c3, t3) = http(
            "POST", "$cloudUrl/v3/auth/refresh_tokens",
            mapOf("content-type" to JSON_TYPE),
            JSONObject().put("userId", username).put("ssoToken", token).put("appId", APP_ID).toString(),
        )
        val d3 = parse(t3, "jeton yenileme", c3).optJSONObject("data")
            ?: throw TclException("jetonlar alınamadı: ${t3.take(160)}")
        val cognitoToken = d3.getString("cognitoToken")
        val saasToken = d3.getString("saasToken")

        // 4) AWS geçici kimlik bilgileri (Cognito)
        val cogBody = JSONObject()
            .put("IdentityId", jwtSub(cognitoToken))
            .put("Logins", JSONObject().put("cognito-identity.amazonaws.com", cognitoToken))
            .toString()
        val (c4, t4) = http(
            "POST", "https://cognito-identity.$region.amazonaws.com/",
            mapOf(
                "X-Amz-Target" to "AWSCognitoIdentityService.GetCredentialsForIdentity",
                "content-type" to "application/x-amz-json-1.1",
                "User-Agent" to "aws-sdk-android/2.22.6 Linux/5.4 Dalvik/2.1.0 en_US",
            ),
            cogBody,
        )
        val j4 = parse(t4, "AWS kimlik", c4)
        val cr = j4.optJSONObject("Credentials")
            ?: throw TclException("AWS kimlik bilgisi alınamadı (HTTP $c4): ${t4.take(160)}")
        val exp = cr.optDouble("Expiration", 0.0)
        val expiresAt = if (exp > 1e9) (exp * 1000).toLong() else System.currentTimeMillis() + 50 * 60 * 1000
        return Session(
            username = username,
            country = country,
            deviceUrl = deviceUrl,
            region = region,
            saasToken = saasToken,
            creds = Creds(
                cr.getString("AccessKeyId"),
                cr.getString("SecretKey"),
                cr.getString("SessionToken"),
                expiresAt,
            ),
        )
    }

    @Synchronized
    private fun session(ctx: Context, force: Boolean = false): Session {
        val s = cached
        if (!force && s != null && s.fresh()) return s
        val sp = Store.p(ctx)
        val user = sp.getString("user", null)
        val pw = sp.getString("pw", null)
        if (user == null || pw == null) throw TclException("Önce uygulamayı açıp giriş yap", true)
        val ns = connect(user, pw)
        cached = ns
        return ns
    }

    private fun <T> withSession(ctx: Context, block: (Session) -> T): T {
        try {
            return try {
                block(session(ctx))
            } catch (e: TclException) {
                if (!e.auth) throw e
                block(session(ctx, force = true))
            }
        } catch (e: IOException) {
            throw TclException("Ağ hatası: ${e.message}")
        }
    }

    /** Uygulamadaki giriş düğmesi: doğrular, kaydeder, klima listesini döndürür. */
    fun login(ctx: Context, user: String, password: String): List<Device> {
        val u = user.trim()
        val pw = md5(password)
        try {
            val s = connect(u, pw)
            cached = s
            Store.p(ctx).edit().putString("user", u).putString("pw", pw).remove("device").apply()
            return listDevices(s)
        } catch (e: IOException) {
            throw TclException("Ağ hatası: ${e.message}")
        }
    }

    // ---------- cihazlar ----------

    private fun listDevices(s: Session): List<Device> {
        val ts = System.currentTimeMillis().toString()
        val n = nonce()
        val (c, t) = http(
            "POST", "${s.deviceUrl}/v3/user/get_things",
            mapOf(
                "platform" to "android",
                "appversion" to "5.4.1",
                "thomeversion" to "4.8.1",
                "accesstoken" to s.saasToken,
                "countrycode" to s.country,
                "accept-language" to "en",
                "timestamp" to ts,
                "nonce" to n,
                "sign" to md5(ts + n + s.saasToken),
                "content-type" to JSON_TYPE,
            ),
            "{}",
        )
        val arr = parse(t, "cihaz listesi", c).optJSONObject("data")?.optJSONArray("data")
            ?: throw TclException("cihaz listesi alınamadı (HTTP $c): ${t.take(160)}")
        val out = ArrayList<Device>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("category") == "AC") {
                out.add(Device(o.getString("deviceId"), o.optString("deviceName", "Klima")))
            }
        }
        if (out.isEmpty()) throw TclException("Hesapta klima bulunamadı")
        return out
    }

    fun devices(ctx: Context): List<Device> = withSession(ctx) { listDevices(it) }

    private fun deviceId(ctx: Context, s: Session): String {
        val sp = Store.p(ctx)
        sp.getString("device", null)?.let { return it }
        val d = listDevices(s).first()
        sp.edit().putString("device", d.id).apply()
        return d.id
    }

    // ---------- AWS IoT (SigV4) ----------

    private fun enc(s: String): String {
        val sb = StringBuilder()
        for (b in s.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xff
            val ok = (c >= 'A'.code && c <= 'Z'.code) ||
                (c >= 'a'.code && c <= 'z'.code) ||
                (c >= '0'.code && c <= '9'.code) ||
                c == '-'.code || c == '_'.code || c == '.'.code || c == '~'.code
            if (ok) sb.append(c.toChar()) else sb.append('%').append("%02X".format(c))
        }
        return sb.toString()
    }

    private fun iot(s: Session, method: String, path: String, query: String, body: String): Pair<Int, String> {
        val host = "data-ats.iot.${s.region}.amazonaws.com"
        val fmt = SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val amz = fmt.format(Date())
        val day = amz.substring(0, 8)

        // SigV4: S3 dışındaki servislerde yol iki kez kodlanır
        val canonPath = path.split("/").joinToString("/") { enc(it) }
        val signedHeaders = "host;x-amz-date;x-amz-security-token"
        val canonHeaders = "host:$host\nx-amz-date:$amz\nx-amz-security-token:${s.creds.sessionToken}\n"
        val canonReq = listOf(method, canonPath, query, canonHeaders, signedHeaders, sha256Hex(body))
            .joinToString("\n")
        val scope = "$day/${s.region}/iotdevicegateway/aws4_request"
        val toSign = "AWS4-HMAC-SHA256\n$amz\n$scope\n${sha256Hex(canonReq)}"

        val kDate = hmac(("AWS4" + s.creds.secretKey).toByteArray(Charsets.UTF_8), day)
        val kRegion = hmac(kDate, s.region)
        val kService = hmac(kRegion, "iotdevicegateway")
        val kSigning = hmac(kService, "aws4_request")
        val signature = hex(hmac(kSigning, toSign))

        val auth = "AWS4-HMAC-SHA256 Credential=${s.creds.accessKey}/$scope, " +
            "SignedHeaders=$signedHeaders, Signature=$signature"
        val url = "https://$host$path" + (if (query.isNotEmpty()) "?$query" else "")
        return http(
            method, url,
            mapOf(
                "x-amz-date" to amz,
                "x-amz-security-token" to s.creds.sessionToken,
                "Authorization" to auth,
                "content-type" to "application/json",
            ),
            if (method == "GET") null else body,
        )
    }

    // ---------- durum ve komut ----------

    fun parseState(raw: String): AcState {
        val st = JSONObject(raw).optJSONObject("state") ?: JSONObject()
        val d = st.optJSONObject("desired") ?: JSONObject()
        val r = st.optJSONObject("reported") ?: JSONObject()

        fun pick(vararg keys: String): Int? {
            for (o in listOf(d, r)) {
                for (k in keys) {
                    if (o.has(k) && !o.isNull(k)) {
                        val v = o.optDouble(k, Double.NaN)
                        if (!v.isNaN()) return v.toInt()
                    }
                }
            }
            return null
        }

        val cur = r.optDouble("currentTemperature", Double.NaN)
        return AcState(
            power = pick("powerSwitch") ?: 0,
            target = pick("targetCelsiusDegree", "targetTemperature") ?: 24,
            current = if (cur.isNaN()) null else cur.toInt(),
            mode = pick("workMode"),
            fan = pick("windSpeed"),
            raw = raw,
        )
    }

    fun fetchState(ctx: Context): AcState = withSession(ctx) { s ->
        val id = deviceId(ctx, s)
        val (c, t) = iot(s, "GET", "/things/$id/shadow", "", "")
        if (c !in 200..299) {
            throw TclException("Durum okunamadı (HTTP $c): ${t.take(120)}", c == 401 || c == 403)
        }
        parseState(t)
    }

    fun send(ctx: Context, patch: JSONObject) {
        withSession(ctx) { s ->
            val id = deviceId(ctx, s)
            val payload = JSONObject()
                .put("state", JSONObject().put("desired", patch))
                .put("clientToken", "mobile_" + System.currentTimeMillis())
                .toString()
            // 1. yol: uygulamanın kullandığı gibi MQTT konusuna HTTP ile yayınla
            val topic = "\$aws/things/$id/shadow/update"
            val path = "/topics/" + URLEncoder.encode(topic, "UTF-8")
            val (c1, t1) = iot(s, "POST", path, "qos=1", payload)
            if (c1 !in 200..299) {
                // 2. yol: gölge (shadow) REST güncellemesi
                val (c2, t2) = iot(s, "POST", "/things/$id/shadow", "", payload)
                if (c2 !in 200..299) {
                    throw TclException(
                        "Komut gönderilemedi (yayın $c1: ${t1.take(80)} / gölge $c2: ${t2.take(80)})",
                        c1 == 401 || c1 == 403 || c2 == 401 || c2 == 403,
                    )
                }
            }
            Unit
        }
    }
}
