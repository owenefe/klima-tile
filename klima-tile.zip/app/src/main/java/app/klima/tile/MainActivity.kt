package app.klima.tile

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var out: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 3, pad, pad)

        val info = TextView(this)
        info.text = "TCL Home e-posta ve şifren yalnızca bu telefonda saklanır.\n" +
            "Giriş yaptıktan sonra bildirim panelini aç → kalem simgesi → " +
            "\"Klima\" kutucuklarını panele sürükle."
        root.addView(info)

        val user = EditText(this)
        user.hint = "TCL Home e-posta"
        user.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        user.setText(Store.p(this).getString("user", ""))
        root.addView(user)

        val pw = EditText(this)
        pw.hint = "Şifre"
        pw.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        root.addView(pw)

        val login = Button(this)
        login.text = "Giriş yap"
        root.addView(login)

        val status = Button(this)
        status.text = "Durumu göster"
        root.addView(status)

        out = TextView(this)
        out.setTextIsSelectable(true)
        out.textSize = 12f
        out.typeface = Typeface.MONOSPACE
        val scroll = ScrollView(this)
        scroll.addView(out)
        root.addView(scroll)

        setContentView(root)

        login.setOnClickListener {
            val u = user.text.toString()
            val p = pw.text.toString()
            if (u.isBlank() || p.isEmpty()) {
                show("E-posta ve şifreyi yaz.")
                return@setOnClickListener
            }
            show("Giriş yapılıyor…")
            Ac.exec.execute {
                val msg = try {
                    val list = Tcl.login(applicationContext, u, p)
                    "Giriş başarılı.\nKlimalar:\n" + list.joinToString("\n") { "- ${it.name} (${it.id})" } +
                        "\n\n" + statusText()
                } catch (e: Exception) {
                    "Giriş hatası: ${e.message}"
                }
                runOnUiThread { show(msg) }
            }
        }

        status.setOnClickListener {
            show("Okunuyor…")
            Ac.exec.execute {
                val msg = statusText()
                runOnUiThread { show(msg) }
            }
        }
    }

    private fun show(s: String) {
        out.text = s
    }

    private fun statusText(): String {
        return try {
            val s = Ac.refresh(applicationContext)
            "Güç: ${s.power}\nHedef: ${s.target}\nOda: ${s.current}\n" +
                "workMode: ${s.mode} (${Ac.modeName(s.mode)})\nwindSpeed: ${s.fan}\n\nHam veri:\n${s.raw}"
        } catch (e: Exception) {
            "Durum okunamadı: ${e.message}"
        }
    }

    override fun onResume() {
        super.onResume()
        val e = Store.error(this)
        if (e != null) show("Son kutucuk hatası:\n$e")
    }
}
