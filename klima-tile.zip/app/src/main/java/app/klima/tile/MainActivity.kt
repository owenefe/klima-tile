package app.klima.tile

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale

private val cBg = Color.parseColor("#0A1A2F")
private val cCard = Color.parseColor("#11294A")
private val cCard2 = Color.parseColor("#1B3F6B")
private val cSel = Color.parseColor("#12385F")
private val cLine = Color.parseColor("#2A4F7C")
private val cText = Color.parseColor("#EAF2FB")
private val cMuted = Color.parseColor("#8EA6C4")
private val cFaint = Color.parseColor("#6B86A8")
private val cDim = Color.parseColor("#7FA0C6")
private val cCyan = Color.parseColor("#4FC3F7")
private val cOrange = Color.parseColor("#FF9800")
private val cGreen = Color.parseColor("#4ADE80")
private val cMint = Color.parseColor("#A7F3D0")
private val cRed = Color.parseColor("#F87171")
private val cBlue = Color.parseColor("#1565C0")
private val cDark = Color.parseColor("#1A1000")

private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Fan hızı simgesi: yükselen dört çubuk, ilk [level] tanesi dolu. */
private class FanBars(ctx: Context, private val level: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = w / 5.2f
        val gap = bw * 0.4f
        val heights = floatArrayOf(0.3f, 0.5f, 0.75f, 1f)
        for (i in 0 until 4) {
            paint.color = if (i < level) cCyan else cDim
            val left = i * (bw + gap)
            val bh = h * heights[i]
            rect.set(left, h - bh, left + bw, h)
            canvas.drawRoundRect(rect, bw / 4f, bw / 4f, paint)
        }
    }
}

class MainActivity : Activity() {
    // giriş ekranı
    private lateinit var loginView: ScrollView
    private lateinit var userBox: EditText
    private lateinit var pwBox: EditText
    private lateinit var rememberBox: CheckBox
    private lateinit var loginMsg: TextView

    // ana ekran
    private lateinit var homeView: ScrollView
    private lateinit var pillDot: View
    private lateinit var pillText: TextView
    private lateinit var tempText: TextView
    private lateinit var powerBtn: LinearLayout
    private lateinit var powerIcon: ImageView
    private lateinit var powerText: TextView
    private lateinit var inText: TextView
    private lateinit var outText: TextView
    private lateinit var errText: TextView
    private lateinit var locText: TextView
    private lateinit var accountText: TextView
    private val modeBtns = LinkedHashMap<Int, LinearLayout>()
    private val fanBtns = LinkedHashMap<Int, LinearLayout>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val frame = FrameLayout(this)
        frame.setBackgroundColor(cBg)
        frame.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            insets
        }
        loginView = buildLogin()
        homeView = buildHome()
        frame.addView(loginView, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(homeView, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(frame)

        applyLoginState()
    }

    // ---------- yardımcılar ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun shape(fill: Int, radiusDp: Int, stroke: Int = Color.TRANSPARENT, strokeDp: Int = 2): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setStroke(dp(strokeDp), stroke)
        return g
    }

    private fun circle(fill: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(fill)
        return g
    }

    private fun label(s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        return l
    }

    private fun lp(w: Int, h: Int, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = dp(top)
        return p
    }

    private fun lpw(h: Int, left: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, h, 1f)
        p.leftMargin = dp(left)
        return p
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(cFaint)
        e.setTextColor(cText)
        e.textSize = 16f
        e.isSingleLine = true
        e.setPadding(dp(16), 0, dp(16), 0)
        e.background = shape(cCard, 16, cLine, 1)
        return e
    }

    private fun prefs() = Store.p(this)

    private fun isLoggedIn(): Boolean = prefs().getBoolean("loggedIn", false) || Tcl.hasSaved(this)

    // ---------- giriş ekranı ----------

    private fun buildLogin(): ScrollView {
        val col = vbox()
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(24), dp(48), dp(24), dp(28))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_launcher_fg)
        logo.background = shape(cBlue, 30)
        col.addView(logo, lp(dp(112), dp(112)))

        val title = label("Klimam", 32f, cText, true)
        col.addView(title, lp(WRAP, WRAP, 14))

        val desc = label("TCL Home hesabınla giriş yap,\nklimanı bildirim panelinden yönet.", 14f, cMuted)
        desc.gravity = Gravity.CENTER
        col.addView(desc, lp(WRAP, WRAP, 10))

        col.addView(label("E-posta", 13f, cMuted, true), lp(MATCH, WRAP, 28))
        userBox = field("ornek@mail.com")
        userBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        userBox.setText(prefs().getString("user", ""))
        col.addView(userBox, lp(MATCH, dp(54), 6))

        col.addView(label("Şifre", 13f, cMuted, true), lp(MATCH, WRAP, 14))
        val pwWrap = FrameLayout(this)
        pwBox = field(if (Tcl.hasSaved(this)) "Şifre (kayıtlı, boş bırakabilirsin)" else "Şifre")
        pwBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        pwBox.setPadding(dp(16), 0, dp(80), 0)
        pwWrap.addView(pwBox, FrameLayout.LayoutParams(MATCH, dp(54)))
        val toggle = label("Göster", 14f, cCyan, true)
        toggle.gravity = Gravity.CENTER
        toggle.setPadding(dp(14), 0, dp(14), 0)
        val tlp = FrameLayout.LayoutParams(WRAP, dp(54))
        tlp.gravity = Gravity.END
        pwWrap.addView(toggle, tlp)
        toggle.setOnClickListener {
            val show = toggle.text.toString() == "Göster"
            pwBox.inputType = InputType.TYPE_CLASS_TEXT or
                (if (show) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
            pwBox.setSelection(pwBox.text.length)
            toggle.text = if (show) "Gizle" else "Göster"
        }
        col.addView(pwWrap, lp(MATCH, dp(54), 6))

        rememberBox = CheckBox(this)
        rememberBox.text = "Beni hatırla"
        rememberBox.setTextColor(cText)
        rememberBox.textSize = 15f
        rememberBox.buttonTintList = ColorStateList.valueOf(cCyan)
        rememberBox.isChecked = prefs().getBoolean("remember", true)
        col.addView(rememberBox, lp(MATCH, dp(48), 8))

        loginMsg = label("", 13f, cRed)
        loginMsg.gravity = Gravity.CENTER
        col.addView(loginMsg, lp(MATCH, WRAP, 12))

        val go = Button(this)
        go.text = "Giriş yap"
        go.isAllCaps = false
        go.textSize = 17f
        go.setTextColor(cDark)
        go.setTypeface(go.typeface, Typeface.BOLD)
        go.background = shape(cOrange, 18, Color.TRANSPARENT, 0)
        go.setOnClickListener { doLogin() }
        col.addView(go, lp(MATCH, dp(58), 12))

        col.addView(
            label("E-posta ve şifren yalnızca bu telefonda saklanır.", 12f, cFaint).also { it.gravity = Gravity.CENTER },
            lp(MATCH, WRAP, 14),
        )
        col.addView(footer(), lp(MATCH, WRAP, 12))

        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun footer(): LinearLayout {
        val f = vbox()
        f.gravity = Gravity.CENTER_HORIZONTAL
        f.addView(label("Edited By Metin E.", 12f, cMuted, true))
        val v = label("Klimam · sürüm 13", 12f, cFaint)
        f.addView(v)
        // Uzun basınca ham durum (hata ayıklama)
        f.setOnLongClickListener {
            showDebug()
            true
        }
        return f
    }

    private fun doLogin() {
        val u = userBox.text.toString()
        val p = pwBox.text.toString()
        if (u.isBlank() || (p.isEmpty() && !Tcl.hasSaved(this))) {
            loginMsg.setTextColor(cRed)
            loginMsg.text = "E-posta ve şifreyi yaz."
            return
        }
        val rem = rememberBox.isChecked
        loginMsg.setTextColor(cMuted)
        loginMsg.text = "Giriş yapılıyor…"
        Ac.exec.execute {
            val err: String? = try {
                Tcl.login(applicationContext, u, p, rem)
                null
            } catch (e: Exception) {
                e.message ?: "Hata"
            }
            if (err == null) {
                Store.p(applicationContext).edit().putBoolean("loggedIn", true).apply()
            }
            runOnUiThread {
                if (err == null) {
                    pwBox.setText("")
                    loginMsg.text = ""
                    applyLoginState()
                } else {
                    loginMsg.setTextColor(cRed)
                    loginMsg.text = "Giriş hatası: $err"
                }
            }
        }
    }

    private fun doLogout() {
        prefs().edit().remove("pw").remove("device").putBoolean("loggedIn", false).apply()
        Ac.last = null
        pwBox.setText("")
        pwBox.hint = "Şifre"
        applyLoginState()
    }

    private fun applyLoginState() {
        val ok = isLoggedIn()
        loginView.visibility = if (ok) View.GONE else View.VISIBLE
        homeView.visibility = if (ok) View.VISIBLE else View.GONE
        if (ok) {
            accountText.text = prefs().getString("user", "") ?: ""
            updateLoc()
            updateUi(Ac.last, null)
            refreshState()
        }
    }

    // ---------- ana ekran ----------

    private fun buildHome(): ScrollView {
        val col = vbox()
        col.setPadding(dp(20), dp(24), dp(20), dp(24))

        // başlık
        val head = hbox()
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_launcher_fg)
        logo.background = shape(cBlue, 14)
        head.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        val names = vbox()
        names.addView(label("Klimam", 20f, cText, true))
        names.addView(label("Split AC", 12f, cMuted))
        val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        nlp.leftMargin = dp(12)
        head.addView(names, nlp)
        val pill = hbox()
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(12), dp(6), dp(12), dp(6))
        pill.background = shape(cCard, 20, Color.TRANSPARENT, 0)
        pillDot = View(this)
        pillDot.background = circle(cMuted)
        pill.addView(pillDot, LinearLayout.LayoutParams(dp(8), dp(8)))
        pillText = label("Bağlanıyor…", 12f, cMuted, true)
        val ptl = LinearLayout.LayoutParams(WRAP, WRAP)
        ptl.leftMargin = dp(6)
        pill.addView(pillText, ptl)
        head.addView(pill, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(head, lp(MATCH, WRAP))

        errText = label("", 12f, cRed)
        col.addView(errText, lp(MATCH, WRAP, 8))

        // büyük kart: hedef sıcaklık ve açma/kapama
        val hero = vbox()
        hero.gravity = Gravity.CENTER_HORIZONTAL
        hero.background = shape(cCard, 28, Color.TRANSPARENT, 0)
        hero.setPadding(dp(18), dp(22), dp(18), dp(20))
        val cap = label("HEDEF SICAKLIK", 12f, cMuted, true)
        cap.letterSpacing = 0.1f
        hero.addView(cap)

        val row = hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        val minus = roundButton("−", "Sıcaklığı azalt")
        minus.setOnClickListener {
            act { JSONObject().put("targetTemperature", maxOf(Ac.TEMP_MIN, it.target - 1)) }
        }
        val plus = roundButton("+", "Sıcaklığı artır")
        plus.setOnClickListener {
            act { JSONObject().put("targetTemperature", minOf(Ac.TEMP_MAX, it.target + 1)) }
        }
        row.addView(minus, LinearLayout.LayoutParams(dp(60), dp(60)))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val tempRow = hbox()
        tempText = label("--", 88f, cText, true)
        tempText.includeFontPadding = false
        tempRow.addView(tempText)
        val unit = label("°C", 30f, cCyan, true)
        val ulp = LinearLayout.LayoutParams(WRAP, WRAP)
        ulp.topMargin = dp(10)
        tempRow.addView(unit, ulp)
        row.addView(tempRow, LinearLayout.LayoutParams(WRAP, WRAP))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(plus, LinearLayout.LayoutParams(dp(60), dp(60)))
        hero.addView(row, lp(MATCH, WRAP, 14))

        powerBtn = hbox()
        powerBtn.gravity = Gravity.CENTER
        powerIcon = ImageView(this)
        powerIcon.setImageResource(R.drawable.ic_power)
        powerBtn.addView(powerIcon, LinearLayout.LayoutParams(dp(24), dp(24)))
        powerText = label("", 16f, cDark, true)
        val pxl = LinearLayout.LayoutParams(WRAP, WRAP)
        pxl.leftMargin = dp(10)
        powerBtn.addView(powerText, pxl)
        powerBtn.setOnClickListener {
            act { JSONObject().put("powerSwitch", if (it.power == 1) 0 else 1) }
        }
        hero.addView(powerBtn, lp(MATCH, dp(56), 16))
        col.addView(hero, lp(MATCH, WRAP, 12))

        // iç / dış sıcaklık
        val temps = hbox()
        val inCard = infoCard("İç sıcaklık")
        inText = inCard.getChildAt(1) as TextView
        val outCard = infoCard("Dış sıcaklık")
        outText = outCard.getChildAt(1) as TextView
        temps.addView(inCard, lpw(WRAP))
        temps.addView(outCard, lpw(WRAP, 12))
        col.addView(temps, lp(MATCH, WRAP, 16))

        // mod
        col.addView(sectionTitle("MOD"), lp(MATCH, WRAP, 22))
        val modes = hbox()
        val defs = listOf(
            Triple(1, "Soğutma", R.drawable.ic_ac),
            Triple(4, "Isıtma", R.drawable.ic_sun),
            Triple(0, "Oto", R.drawable.ic_auto),
        )
        val tints = mapOf(1 to cCyan, 4 to cOrange, 0 to cMint)
        for ((i, d) in defs.withIndex()) {
            val b = vbox()
            b.gravity = Gravity.CENTER
            val ic = ImageView(this)
            ic.setImageResource(d.third)
            ic.setColorFilter(tints[d.first] ?: cText)
            b.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))
            val t = label(d.second, 14f, cText, true)
            b.addView(t, lp(WRAP, WRAP, 4))
            b.setOnClickListener { act { JSONObject().put("workMode", d.first) } }
            modeBtns[d.first] = b
            modes.addView(b, lpw(dp(64), if (i == 0) 0 else 8))
        }
        col.addView(modes, lp(MATCH, WRAP, 10))

        // fan hızı
        col.addView(sectionTitle("FAN HIZI"), lp(MATCH, WRAP, 22))
        val fans = hbox()
        val fdefs = listOf(
            Triple(1, "Sessiz", 0),
            Triple(2, "Düşük", 2),
            Triple(4, "Orta", 3),
            Triple(7, "Kuvvetli", 4),
            Triple(0, "Oto", -1),
        )
        for ((i, d) in fdefs.withIndex()) {
            val b = vbox()
            b.gravity = Gravity.CENTER
            if (d.third >= 0) {
                b.addView(FanBars(this, d.third), LinearLayout.LayoutParams(dp(24), dp(20)))
            } else {
                val ic = ImageView(this)
                ic.setImageResource(R.drawable.ic_auto)
                ic.setColorFilter(cMint)
                b.addView(ic, LinearLayout.LayoutParams(dp(24), dp(20)))
            }
            b.addView(label(d.second, 11f, cText, true), lp(WRAP, WRAP, 8))
            b.setOnClickListener { act { JSONObject().put("windSpeed", d.first) } }
            fanBtns[d.first] = b
            fans.addView(b, lpw(dp(76), if (i == 0) 0 else 6))
        }
        col.addView(fans, lp(MATCH, WRAP, 10))

        // konum
        val loc = vbox()
        loc.background = shape(cCard, 22, Color.TRANSPARENT, 0)
        loc.setPadding(dp(16), dp(16), dp(16), dp(16))
        loc.addView(sectionTitle("DIŞ SICAKLIK İÇİN KONUM"))
        locText = label("", 14f, cText, true)
        locText.setPadding(dp(12), dp(10), dp(12), dp(10))
        locText.background = shape(cSel, 12, Color.TRANSPARENT, 0)
        loc.addView(locText, lp(MATCH, WRAP, 12))
        val lrow = hbox()
        val useLoc = outlineButton("Konumumu kullan", cCyan, true)
        useLoc.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                fetchLocation()
            } else {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
            }
        }
        val pick = outlineButton("İl / ilçe seç", cText, false)
        pick.setOnClickListener { pickCity() }
        lrow.addView(useLoc, lpw(dp(48)))
        lrow.addView(pick, lpw(dp(48), 10))
        loc.addView(lrow, lp(MATCH, WRAP, 12))
        col.addView(loc, lp(MATCH, WRAP, 22))

        // hesap
        val acc = hbox()
        acc.gravity = Gravity.CENTER_VERTICAL
        val who = vbox()
        who.addView(label("✓ Giriş yapıldı", 13f, cGreen, true))
        accountText = label("", 13f, cMuted)
        who.addView(accountText)
        acc.addView(who, LinearLayout.LayoutParams(0, WRAP, 1f))
        val out = outlineButton("Çıkış yap", cText, false)
        out.setOnClickListener { doLogout() }
        acc.addView(out, LinearLayout.LayoutParams(WRAP, dp(44)))
        col.addView(acc, lp(MATCH, WRAP, 22))

        col.addView(footer(), lp(MATCH, WRAP, 24))

        val sv = ScrollView(this)
        sv.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun roundButton(sign: String, desc: String): TextView {
        val t = label(sign, 30f, cText, true)
        t.gravity = Gravity.CENTER
        t.background = circle(cCard2)
        t.contentDescription = desc
        t.isClickable = true
        return t
    }

    private fun sectionTitle(s: String): TextView {
        val t = label(s, 13f, cMuted, true)
        t.letterSpacing = 0.06f
        return t
    }

    private fun infoCard(title: String): LinearLayout {
        val c = vbox()
        c.background = shape(cCard, 20, Color.TRANSPARENT, 0)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.addView(label(title, 12f, cMuted, true))
        c.addView(label("--", 30f, cText, true), lp(WRAP, WRAP, 4))
        return c
    }

    private fun outlineButton(s: String, color: Int, accent: Boolean): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(color)
        b.setPadding(dp(8), 0, dp(8), 0)
        b.background = shape(Color.TRANSPARENT, 14, if (accent) cCyan else cLine, 1)
        return b
    }

    private fun styleSel(b: View, sel: Boolean, radius: Int) {
        b.background = if (sel) shape(cSel, radius, cCyan, 2) else shape(cCard, radius, Color.TRANSPARENT, 2)
    }

    private fun updateUi(s: AcState?, err: String?) {
        tempText.text = if (s == null) "--" else s.target.toString()
        inText.text = if (s?.current != null) "${s.current}°" else "--"
        outText.text = if (s?.outdoor != null) "${s.outdoor}°" else "--"

        val on = s?.power == 1
        if (on) {
            powerBtn.background = shape(cOrange, 18, Color.TRANSPARENT, 0)
            powerText.setTextColor(cDark)
            powerText.text = "Klima açık · Kapatmak için dokun"
            powerIcon.setColorFilter(cDark)
        } else {
            powerBtn.background = shape(cCard2, 18, Color.TRANSPARENT, 0)
            powerText.setTextColor(cText)
            powerText.text = "Klima kapalı · Açmak için dokun"
            powerIcon.setColorFilter(cText)
        }

        for ((code, b) in modeBtns) styleSel(b, s?.mode == code, 18)
        for ((code, b) in fanBtns) styleSel(b, s?.fan == code, 14)

        when {
            err != null -> {
                pillDot.background = circle(cRed)
                pillText.setTextColor(cRed)
                pillText.text = "Bağlantı yok"
                errText.text = err
            }
            s != null -> {
                pillDot.background = circle(cGreen)
                pillText.setTextColor(cGreen)
                pillText.text = "Bağlı"
                errText.text = ""
            }
            else -> {
                pillDot.background = circle(cMuted)
                pillText.setTextColor(cMuted)
                pillText.text = "Bağlanıyor…"
                errText.text = ""
            }
        }
    }

    private fun updateLoc() {
        val sp = prefs()
        val il = (sp.getString("il", "") ?: "").trim()
        val ilce = (sp.getString("ilce", "") ?: "").trim()
        val place = listOf(il, ilce).filter { it.isNotEmpty() }.joinToString(" / ")
        val text = when {
            place.isNotEmpty() -> place
            sp.getBoolean("useLoc", false) -> "telefon konumu"
            else -> "seçilmedi"
        }
        locText.text = "Seçili konum: $text"
    }

    // ---------- klima işlemleri ----------

    private fun act(make: (AcState) -> JSONObject?) {
        Ac.exec.execute {
            var st: AcState? = null
            var err: String? = null
            try {
                st = Ac.apply(applicationContext, make)
                Store.setError(applicationContext, null)
            } catch (e: Exception) {
                err = e.message ?: "Hata"
                Store.setError(applicationContext, err)
            }
            val shown = st ?: Ac.last
            val msg = err
            runOnUiThread { updateUi(shown, msg) }
        }
    }

    private fun refreshState() {
        Ac.exec.execute {
            var st: AcState? = null
            var err: String? = null
            try {
                st = Ac.refresh(applicationContext)
                Store.setError(applicationContext, null)
            } catch (e: Exception) {
                err = e.message ?: "Hata"
                Store.setError(applicationContext, err)
            }
            val shown = st ?: Ac.last
            val msg = err
            runOnUiThread { updateUi(shown, msg) }
        }
    }

    // ---------- konum ----------

    private fun pickCity() {
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val il = EditText(this)
        il.hint = "İl"
        il.setText(prefs().getString("il", ""))
        val ilce = EditText(this)
        ilce.hint = "İlçe"
        ilce.setText(prefs().getString("ilce", ""))
        box.addView(il)
        box.addView(ilce)
        AlertDialog.Builder(this)
            .setTitle("İl / ilçe seç")
            .setView(box)
            .setPositiveButton("Kaydet") { _, _ ->
                prefs().edit()
                    .putString("il", il.text.toString().trim())
                    .putString("ilce", ilce.text.toString().trim())
                    .putBoolean("useLoc", false)
                    .apply()
                updateLoc()
                refreshState()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchLocation()
            } else {
                locText.text = "Konum izni verilmedi. İl / ilçe seçebilirsin."
            }
        }
    }

    private fun saveLoc(l: Location) {
        prefs().edit()
            .putFloat("lat", l.latitude.toFloat())
            .putFloat("lon", l.longitude.toFloat())
            .putBoolean("useLoc", true)
            .putString("il", "")
            .putString("ilce", "")
            .apply()
        runOnUiThread { updateLoc() }
        Ac.exec.execute {
            val n = reverseName(l.latitude, l.longitude)
            if (n != null) {
                Store.p(applicationContext).edit()
                    .putString("il", n.first)
                    .putString("ilce", n.second)
                    .apply()
            }
            runOnUiThread { updateLoc() }
            refreshState()
        }
    }

    @Suppress("DEPRECATION")
    private fun reverseName(lat: Double, lon: Double): Pair<String, String>? {
        if (!Geocoder.isPresent()) return null
        return try {
            val a = Geocoder(this, Locale("tr", "TR")).getFromLocation(lat, lon, 1)?.firstOrNull()
            if (a == null) null else Pair(a.adminArea ?: "", a.subAdminArea ?: a.locality ?: "")
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchLocation() {
        locText.text = "Konum alınıyor…"
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val b = best
                if (l != null && (b == null || l.time > b.time)) best = l
            } catch (_: SecurityException) {
            } catch (_: IllegalArgumentException) {
            }
        }
        val found = best
        if (found != null) {
            saveLoc(found)
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, mainExecutor) { loc ->
                    if (loc != null) {
                        saveLoc(loc)
                    } else {
                        locText.text = "Konum alınamadı. Konum ayarı açık mı? İl / ilçe seçebilirsin."
                    }
                }
            } catch (e: Exception) {
                locText.text = "Konum alınamadı: ${e.message}"
            }
        } else {
            locText.text = "Konum alınamadı. İl / ilçe seçebilirsin."
        }
    }

    // ---------- hata ayıklama (sürüm yazısına uzun bas) ----------

    private fun showDebug() {
        Ac.exec.execute {
            val msg = statusText()
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("Ham durum")
                    .setMessage(msg)
                    .setPositiveButton("Tamam", null)
                    .show()
            }
        }
    }

    private fun statusText(): String {
        return try {
            val s = Ac.refresh(applicationContext)
            val rep = JSONObject(s.raw).optJSONObject("state")?.optJSONObject("reported")
            val keys = listOf(
                "powerSwitch", "workMode", "targetTemperature", "currentTemperature", "windSpeed",
                "turbo", "ECO", "sleep", "silenceSwitch", "screen",
            )
            "Güç: ${s.power}\nHedef: ${s.target}\nİç: ${s.current}\nDış: ${s.outdoor ?: "?"}\n" +
                "Mod: ${Ac.modeName(s.mode)} (workMode ${s.mode})\nFan: ${Ac.fanName(s.fan)} (windSpeed ${s.fan})\n\n" +
                keys.joinToString("\n") { k -> "$k: ${rep?.opt(k)}" }
        } catch (e: Exception) {
            "Durum okunamadı: ${e.message}"
        }
    }

    override fun onPause() {
        if (this::userBox.isInitialized) {
            val e = prefs().edit().putBoolean("remember", rememberBox.isChecked)
            if (userBox.text.isNotBlank()) e.putString("user", userBox.text.toString().trim())
            e.apply()
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (this::homeView.isInitialized && isLoggedIn()) {
            updateLoc()
            refreshState()
        }
    }

    companion object {
        private const val REQ_LOC = 7
    }
}
