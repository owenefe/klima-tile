package app.klima.tile

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var ilBox: EditText
    private lateinit var ilceBox: EditText
    private var uiRefresh: (() -> Unit)? = null
    private var saveUi: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 3, pad, pad)

        val info = TextView(this)
        info.text = "TCL Home e-posta ve şifren yalnızca bu telefonda saklanır.\n" +
            "Giriş yaptıktan sonra bildirim panelini aç → kalem simgesi → " +
            "\"Klima\" kutucuklarını panele sürükle."
        root.addView(info)

        val loginBox = LinearLayout(this)
        loginBox.orientation = LinearLayout.VERTICAL
        val loggedBox = LinearLayout(this)
        loggedBox.orientation = LinearLayout.VERTICAL
        val loggedText = TextView(this)
        loggedText.textSize = 16f
        loggedBox.addView(loggedText)
        val logout = Button(this)
        logout.text = "Çıkış yap / hesabı değiştir"
        loggedBox.addView(logout)
        root.addView(loggedBox)
        root.addView(loginBox)

        val user = EditText(this)
        user.hint = "TCL Home e-posta"
        user.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        user.setText(Store.p(this).getString("user", ""))
        loginBox.addView(user)

        val pw = EditText(this)
        pw.hint = if (Tcl.hasSaved(this)) "Şifre (kayıtlı, boş bırakabilirsin)" else "Şifre"
        pw.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        loginBox.addView(pw)

        val showPw = CheckBox(this)
        showPw.text = "Şifreyi göster"
        showPw.isChecked = Store.p(this).getBoolean("showPw", false)
        showPw.setOnCheckedChangeListener { _, on ->
            pw.inputType = InputType.TYPE_CLASS_TEXT or
                (if (on) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
            pw.setSelection(pw.text.length)
        }
        if (showPw.isChecked) {
            pw.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        }
        loginBox.addView(showPw)

        val remember = CheckBox(this)
        remember.text = "Beni hatırla (kutucukların çalışması için gerekli)"
        remember.isChecked = Store.p(this).getBoolean("remember", true)
        loginBox.addView(remember)

        val weatherInfo = TextView(this)
        weatherInfo.text = "\nDış sıcaklık için il/ilçe yaz ya da konumunu kullan:"
        root.addView(weatherInfo)

        ilBox = EditText(this)
        ilBox.hint = "İl"
        ilBox.setText(Store.p(this).getString("il", ""))
        root.addView(ilBox)

        ilceBox = EditText(this)
        ilceBox.hint = "İlçe"
        ilceBox.setText(Store.p(this).getString("ilce", ""))
        root.addView(ilceBox)

        val locBtn = Button(this)
        locBtn.text = "Konumumu kullan"
        root.addView(locBtn)

        val login = Button(this)
        login.text = "Giriş yap"
        loginBox.addView(login)

        val status = Button(this)
        status.text = "Durumu göster"
        root.addView(status)

        out = TextView(this)
        out.setTextIsSelectable(true)
        out.textSize = 12f
        out.typeface = Typeface.MONOSPACE
        root.addView(out)

        saveUi = {
            val e = Store.p(this).edit()
                .putString("il", ilBox.text.toString().trim())
                .putString("ilce", ilceBox.text.toString().trim())
                .putBoolean("showPw", showPw.isChecked)
                .putBoolean("remember", remember.isChecked)
            if (user.text.isNotBlank()) e.putString("user", user.text.toString().trim())
            e.apply()
        }

        fun refreshLoginUi() {
            val sp = Store.p(this)
            val ok = sp.getBoolean("loggedIn", false) || Tcl.hasSaved(this)
            loggedBox.visibility = if (ok) View.VISIBLE else View.GONE
            loginBox.visibility = if (ok) View.GONE else View.VISIBLE
            loggedText.text = "✓ Giriş yapıldı\n" + (sp.getString("user", "") ?: "")
        }
        uiRefresh = ::refreshLoginUi
        refreshLoginUi()

        logout.setOnClickListener {
            Store.p(this).edit().remove("pw").remove("device").putBoolean("loggedIn", false).apply()
            pw.setText("")
            pw.hint = "Şifre"
            show("Çıkış yapıldı.")
            refreshLoginUi()
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        locBtn.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                fetchLocation()
            } else {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
            }
        }

        login.setOnClickListener {
            val u = user.text.toString()
            val p = pw.text.toString()
            if (u.isBlank() || (p.isEmpty() && !Tcl.hasSaved(this))) {
                show("E-posta ve şifreyi yaz.")
                return@setOnClickListener
            }
            val rem = remember.isChecked
            saveCity()
            show("Giriş yapılıyor…")
            Ac.exec.execute {
                val msg = try {
                    val list = Tcl.login(applicationContext, u, p, rem)
                    "Giriş başarılı.\nKlimalar:\n" + list.joinToString("\n") { "- ${it.name} (${it.id})" } +
                        "\n\n" + statusText()
                } catch (e: Exception) {
                    "Giriş hatası: ${e.message}"
                }
                val ok = msg.startsWith("Giriş başarılı")
                if (ok) Store.p(applicationContext).edit().putBoolean("loggedIn", true).apply()
                runOnUiThread {
                    show(msg)
                    if (ok) {
                        pw.setText("")
                        uiRefresh?.invoke()
                    }
                }
            }
        }

        status.setOnClickListener {
            saveCity()
            show("Okunuyor…")
            Ac.exec.execute {
                val msg = statusText()
                runOnUiThread { show(msg) }
            }
        }
    }

    private fun saveCity() {
        val il = ilBox.text.toString().trim()
        val ilce = ilceBox.text.toString().trim()
        val e = Store.p(this).edit().putString("il", il).putString("ilce", ilce)
        // İl/ilçe yazıldıysa konum yerine onlar kullanılır
        if (il.isNotEmpty() || ilce.isNotEmpty()) e.putBoolean("useLoc", false)
        e.apply()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchLocation()
            } else {
                show("Konum izni verilmedi. İl ve ilçeyi elle yazabilirsin.")
            }
        }
    }

    private fun saveLoc(l: Location) {
        Store.p(this).edit()
            .putFloat("lat", l.latitude.toFloat())
            .putFloat("lon", l.longitude.toFloat())
            .putBoolean("useLoc", true)
            .putString("il", "")
            .putString("ilce", "")
            .apply()
        runOnUiThread {
            ilBox.setText("")
            ilceBox.setText("")
            show("Konum kaydedildi. Dış sıcaklık konumuna göre alınacak.")
        }
    }

    private fun fetchLocation() {
        show("Konum alınıyor…")
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val b = best
                if (l != null && (b == null || l.time > b.time)) best = l
            } catch (_: SecurityException) {
            } catch (_: IllegalArgumentException) {
            }
        }
        val found = best
        if (found != null) {
            saveLoc(found)
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, mainExecutor) { loc ->
                    if (loc != null) {
                        saveLoc(loc)
                    } else {
                        show("Konum alınamadı. Telefonun konum ayarı açık mı? İl ve ilçeyi elle yazabilirsin.")
                    }
                }
            } catch (e: Exception) {
                show("Konum alınamadı: ${e.message}")
            }
        } else {
            show("Konum alınamadı. İl ve ilçeyi elle yazabilirsin.")
        }
    }

    private fun show(s: String) {
        out.text = s
    }

    private fun statusText(): String {
        return try {
            val s = Ac.refresh(applicationContext)
            val rep = org.json.JSONObject(s.raw).optJSONObject("state")?.optJSONObject("reported")
            val keys = listOf(
                "powerSwitch", "workMode", "targetTemperature", "currentTemperature", "windSpeed",
                "turbo", "ECO", "sleep", "silenceSwitch", "screen",
            )
            "Güç: ${s.power}\nHedef: ${s.target}\nİç: ${s.current}\nDış: ${s.outdoor ?: "?"}\n" +
                "Mod: ${Ac.modeName(s.mode)} (workMode ${s.mode})\nFan: ${Ac.fanName(s.fan)} (windSpeed ${s.fan})\n\n" +
                keys.joinToString("\n") { k -> "$k: ${rep?.opt(k)}" }
        } catch (e: Exception) {
            "Durum okunamadı: ${e.message}"
        }
    }

    override fun onPause() {
        saveUi?.invoke()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        val e = Store.error(this)
        if (e != null) show("Son kutucuk hatası:\n$e")
    }

    companion object {
        private const val REQ_LOC = 7
    }
}
