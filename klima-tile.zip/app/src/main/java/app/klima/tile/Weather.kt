package app.klima.tile

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Dış sıcaklık: klimanın verisinde yok, bu yüzden Open-Meteo'dan (ücretsiz, anahtarsız)
 * kayıtlı konum ya da il/ilçe için çekilir. 10 dakika önbelleğe alınır.
 */
object Weather {
    @Volatile
    private var cachedTemp: Int? = null

    @Volatile
    private var cachedAt = 0L

    @Volatile
    private var cachedKey = ""

    fun outdoor(ctx: Context): Int? {
        val sp = Store.p(ctx)
        val il = (sp.getString("il", "") ?: "").trim()
        val ilce = (sp.getString("ilce", "") ?: "").trim()
        val useLoc = sp.getBoolean("useLoc", false) && sp.contains("lat") && sp.contains("lon")
        if (!useLoc && il.isEmpty() && ilce.isEmpty()) return null

        val key = if (useLoc) {
            "loc:${sp.getFloat("lat", 0f)},${sp.getFloat("lon", 0f)}"
        } else {
            "$il|$ilce"
        }
        val now = System.currentTimeMillis()
        if (key == cachedKey && now - cachedAt < 10 * 60 * 1000) return cachedTemp

        try {
            val lat: Double
            val lon: Double
            if (useLoc) {
                lat = sp.getFloat("lat", 0f).toDouble()
                lon = sp.getFloat("lon", 0f).toDouble()
            } else {
                val p = geocode(il, ilce) ?: return null
                lat = p.first
                lon = p.second
            }
            val w = get(
                "https://api.open-meteo.com/v1/forecast?current=temperature_2m&latitude=$lat&longitude=$lon",
            )
            val t = JSONObject(w).getJSONObject("current").getDouble("temperature_2m")
            cachedTemp = Math.round(t).toInt()
            cachedAt = now
            cachedKey = key
            return cachedTemp
        } catch (e: Exception) {
            return if (key == cachedKey) cachedTemp else null
        }
    }

    private fun norm(s: String): String =
        s.lowercase(Locale.forLanguageTag("tr"))
            .replace('ı', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')

    /** İlçe adıyla arar, sonuçlardan ili eşleşeni seçer; ilçe yoksa il adıyla arar. */
    private fun geocode(il: String, ilce: String): Pair<Double, Double>? {
        val name = if (ilce.isNotEmpty()) ilce else il
        val g = get(
            "https://geocoding-api.open-meteo.com/v1/search?count=10&language=tr&countryCode=TR&name=" +
                URLEncoder.encode(name, "UTF-8"),
        )
        val arr = JSONObject(g).optJSONArray("results") ?: return null
        var first: JSONObject? = null
        var match: JSONObject? = null
        val wanted = norm(il)
        for (i in 0 until arr.length()) {
            val r = arr.optJSONObject(i) ?: continue
            if (first == null) first = r
            if (il.isEmpty() || ilce.isEmpty()) {
                match = r
                break
            }
            val hay = listOf("admin1", "admin2", "admin3", "admin4").joinToString(" ") { norm(r.optString(it, "")) }
            if (hay.contains(wanted)) {
                match = r
                break
            }
        }
        val r = match ?: first ?: return null
        return Pair(r.getDouble("latitude"), r.getDouble("longitude"))
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        try {
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
