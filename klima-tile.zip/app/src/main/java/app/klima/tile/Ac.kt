package app.klima.tile

import android.content.Context
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Klimanın son bilinen durumu ve kutucukların kullandığı ortak mantık.
 *
 * Doğrulananlar: workMode 4 = Isıtma, windSpeed 5 = Orta-yüksek.
 * Diğer sayılar TCL uygulamasındaki sıraya ve sık kullanılan TCL kodlarına göre
 * tahmin edildi; kutucuğa basınca TCL uygulamasındaki ad ile karşılaştırılıp
 * yanlış olan düzeltilecek.
 */
object Ac {
    val exec: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile
    var last: AcState? = null

    @Volatile
    private var lastAt = 0L

    val MODE_NAMES: Map<Int, String> = mapOf(
        0 to "Oto.",
        1 to "Soğuk",
        2 to "Nemsizleştirme",
        3 to "Fan",
        4 to "Isıtma",
    )

    // Kutucuğun döndüğü modlar: Soğuk, Isıtma, Oto.
    val MODE_CYCLE: List<Int> = listOf(1, 4, 0)

    val FAN_NAMES: Map<Int, String> = mapOf(
        0 to "Oto.",
        1 to "Sessiz",
        2 to "Düşük",
        3 to "Orta-düşük",
        4 to "Orta",
        5 to "Orta-yüksek",
        6 to "Yüksek",
        7 to "Kuvvetli",
    )
    // Kutucuğun döndüğü fan hızları: Sessiz, Düşük, Orta, Kuvvetli, Oto.
    val FAN_CYCLE: List<Int> = listOf(1, 2, 4, 7, 0)

    const val TEMP_MIN = 16
    const val TEMP_MAX = 31

    fun modeName(m: Int?): String = if (m == null) "?" else (MODE_NAMES[m] ?: "Mod $m")
    fun fanName(f: Int?): String = if (f == null) "?" else (FAN_NAMES[f] ?: "Hız $f")

    fun describe(s: AcState): String =
        "Güç: ${if (s.power == 1) "Açık" else "Kapalı"}\n" +
            "Mod: ${modeName(s.mode)}\n" +
            "Hedef: ${s.target}°\n" +
            "İç: ${s.current ?: "?"}°\n" +
            "Dış: ${s.outdoor ?: "?"}°\n" +
            "Fan: ${fanName(s.fan)}"

    fun next(cycle: List<Int>, cur: Int?): Int {
        val i = if (cur == null) -1 else cycle.indexOf(cur)
        return cycle[(i + 1) % cycle.size]
    }

    fun refresh(ctx: Context, maxAgeMs: Long = 0): AcState {
        val l = last
        if (l != null && System.currentTimeMillis() - lastAt < maxAgeMs) return l
        val s = Tcl.fetchState(ctx).copy(outdoor = Weather.outdoor(ctx))
        last = s
        lastAt = System.currentTimeMillis()
        return s
    }

    fun apply(ctx: Context, make: (AcState) -> JSONObject?): AcState {
        val cur = refresh(ctx, 3000)
        val patch = make(cur) ?: return cur
        Tcl.send(ctx, patch)
        val n = cur.copy(
            power = if (patch.has("powerSwitch")) patch.optInt("powerSwitch") else cur.power,
            target = if (patch.has("targetTemperature")) patch.optInt("targetTemperature") else cur.target,
            mode = if (patch.has("workMode")) patch.optInt("workMode") else cur.mode,
            fan = if (patch.has("windSpeed")) patch.optInt("windSpeed") else cur.fan,
        )
        last = n
        lastAt = System.currentTimeMillis()
        return n
    }
}
