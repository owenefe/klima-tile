# Klima Kutucuk

TCL Home klimayı Samsung bildirim panelindeki 5 kutucukla yönetir:
Aç/kapat, Sıcaklık +, Sıcaklık −, Mod, Fan. Her kutucuk canlı durumu gösterir.

Resmi olmayan TCL Home bulut protokolünü kullanır (açık kaynak `homebridge-tcl-home` eklentisinden uyarlandı).
E-posta ve şifre yalnızca telefondaki uygulama verisinde (MD5 özeti olarak) saklanır.

## Kurulum
1. GitHub'da Actions derlemesi bitince **Releases → Son derleme → klima-tile.apk** dosyasını telefona indir ve kur.
2. Uygulamayı aç, TCL Home e-posta ve şifrenle giriş yap.
3. Bildirim panelini aç → kalem simgesi → "Klima" kutucuklarını sürükle.

## İlk testte yapılacak
"Durumu göster" ekranı klimanın ham verisini gösterir. Mod ve fan sayılarının anlamı
(`Ac.kt` içindeki `MODE_NAMES`, `MODE_CYCLE`, `FAN_CYCLE`) bu ekrana bakılarak düzeltilecek.
